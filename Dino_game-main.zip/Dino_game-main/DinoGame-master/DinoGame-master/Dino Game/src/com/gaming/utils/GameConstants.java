package com.gaming.utils;

public interface GameConstants {
	int GHEIGHT = 800;
	int GWIDTH = 1500;
	String TITLE = "Chrome Dino Game ..";
	int FLOOR = 700;
	String DINO_IMAGE = "img.png";
	int GRAVITY = 1;
	int DEFAULTFORCE = -25;
}
