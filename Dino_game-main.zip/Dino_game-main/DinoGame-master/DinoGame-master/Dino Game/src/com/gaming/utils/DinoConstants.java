package com.gaming.utils;

public interface DinoConstants {
	int STANDING = 1;
	int JUMP = 2;
}
